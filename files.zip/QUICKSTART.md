# 🚀 QUICK START — Instagram AI Art Bot

## Files in this folder

| File | Purpose |
|------|---------|
| `bot.py` | Main bot — generates & posts 10 images daily |
| `.env.example` | Copy to `.env` and add your API keys |
| `requirements.txt` | Python packages to install |
| `.github/workflows/daily_post.yml` | GitHub Actions — FREE daily automation |

---

## ⚡ Setup in 5 Steps

### 1. Install Python packages
```bash
pip install -r requirements.txt
```

### 2. Get your 4 API keys

| Key | Where to get it | Cost |
|-----|----------------|------|
| `OPENAI_API_KEY` | platform.openai.com/api-keys | ~₹0.08/image |
| `INSTAGRAM_ACCOUNT_ID` | developers.facebook.com | Free |
| `META_ACCESS_TOKEN` | developers.facebook.com → Graph API Explorer | Free |
| `IMGUR_CLIENT_ID` | api.imgur.com/oauth2/addclient | Free |

### 3. Create your .env file
```bash
cp .env.example .env
# Open .env and paste your keys
```

### 4. Test it works
```bash
python bot.py test
# Generates 1 image + caption preview, no posting
```

### 5. Run it!
```bash
python bot.py now       # Post all 10 images right now
python bot.py           # Schedule daily at 8 AM
python bot.py single 3  # Post only theme #3 (Floating Space Observatory)
```

---

## 🆓 Free Automation with GitHub Actions

1. Push this entire folder to a **GitHub repository**
2. Go to your repo → **Settings** → **Secrets and variables** → **Actions**
3. Add these 4 secrets:
   - `OPENAI_API_KEY`
   - `INSTAGRAM_ACCOUNT_ID`
   - `META_ACCESS_TOKEN`
   - `IMGUR_CLIENT_ID`
4. Go to **Actions** tab → enable workflows
5. Bot will run **every day at 8 AM IST automatically — 100% free** ✅

---

## 🎨 10 Daily Themes

| # | Theme | Vibe |
|---|-------|------|
| 1 | Cyberpunk Neon Command Center | Dark, electric, cinematic |
| 2 | Cozy Lo-Fi Golden Hour Studio | Warm, cozy, golden |
| 3 | Floating Space Observatory | Epic, cosmic, awe-inspiring |
| 4 | Enchanted Forest Artist Cottage | Magical, ethereal, fantasy |
| 5 | Minimalist Zen White Studio | Clean, luxury, zen |
| 6 | Retro Synthwave Arcade Studio | Neon, retro, electric |
| 7 | Underwater Bioluminescent Studio | Surreal, blue, dreamlike |
| 8 | Victorian Library Meets Future | Steampunk, rich, dramatic |
| 9 | Pastel Kawaii Dream Studio | Cute, pastel, joyful |
| 10 | Industrial Loft Artist Sanctuary | Industrial, raw, sophisticated |

---

## 💰 Daily Cost Estimate

| Item | Cost |
|------|------|
| 10 × DALL-E 3 HD images | ~₹65/day |
| 10 × GPT-4o captions | ~₹2/day |
| Imgur hosting | Free |
| GitHub Actions | Free |
| **Total** | **~₹67/day** |

---

## 📊 Logs

Every post is logged to `post_log.json` with:
- Timestamp
- Theme name
- Image path
- Caption preview
- Instagram media ID
- Post status (posted / failed)
