"""
╔══════════════════════════════════════════════════════════════╗
║     Instagram AI Digital Art Workspace Bot                   ║
║     • 10 Ultra-HD posts daily via DALL-E 3                  ║
║     • GPT-4o captions with emojis & hashtags                ║
║     • Auto-posts to Instagram Business Account              ║
║     • Imgur hosting for public image URLs                   ║
╚══════════════════════════════════════════════════════════════╝

Setup:
    pip install openai requests schedule python-dotenv pillow
    cp .env.example .env  →  fill in your keys
    python bot.py test    →  test one image
    python bot.py now     →  post all 10 now
    python bot.py         →  run daily at 8 AM
"""

import os, time, json, random, schedule, requests, sys
from datetime import datetime
from openai import OpenAI
from dotenv import load_dotenv
from PIL import Image
import io

load_dotenv()

# ══════════════════════════════════════════════
# CREDENTIALS
# ══════════════════════════════════════════════
client               = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
INSTAGRAM_ACCOUNT_ID = os.getenv("INSTAGRAM_ACCOUNT_ID")
ACCESS_TOKEN         = os.getenv("META_ACCESS_TOKEN")
IMGUR_CLIENT_ID      = os.getenv("IMGUR_CLIENT_ID")
SAVE_DIR             = "generated_images"
LOG_FILE             = "post_log.json"
os.makedirs(SAVE_DIR, exist_ok=True)

# ══════════════════════════════════════════════
# 10 ULTRA-DETAILED DAILY THEMES
# Each prompt is engineered for maximum visual
# quality, detail & Instagram appeal
# ══════════════════════════════════════════════
THEMES = [
    {
        "id": 1,
        "name": "Cyberpunk Neon Command Center",
        "prompt": (
            "An ultra-detailed cyberpunk digital artist command center, 4K hyper-realistic digital painting. "
            "Multiple curved ultrawide monitors displaying vibrant generative art. Neon blue and violet "
            "underglow beneath a floating glass desk. Holographic floating UI panels. Rain streaking "
            "floor-to-ceiling windows revealing a futuristic megacity at night. Custom RGB mechanical "
            "keyboard, high-end graphics tablet, noise-cancelling headphones. Dramatic cinematic lighting, "
            "god rays, lens flare, shallow depth of field. Octane render quality, 8K textures."
        ),
        "hook": "⚡ The future of creativity is HERE.",
        "vibe": "dark, electric, cinematic"
    },
    {
        "id": 2,
        "name": "Cozy Lo-Fi Golden Hour Studio",
        "prompt": (
            "An incredibly cozy lo-fi digital art studio bathed in warm golden hour sunlight, "
            "ultra-detailed digital illustration with painterly quality. Vintage wooden desk by a large "
            "bay window with sheer linen curtains gently swaying. Glowing Cintiq drawing tablet with a "
            "half-finished digital painting. Overflowing bookshelves, trailing pothos plants, ceramic mug "
            "of matcha tea steaming softly. Fairy lights, warm amber pendant lamp. Dust motes in golden "
            "light beams. Film grain texture, Studio Ghibli meets editorial photography, 8K quality."
        ),
        "hook": "🍵 Your dream studio called — it wants you back.",
        "vibe": "warm, cozy, golden"
    },
    {
        "id": 3,
        "name": "Floating Space Observatory Workstation",
        "prompt": (
            "A breathtaking sci-fi digital artist workstation inside a glass observation dome orbiting "
            "Earth, ultra-detailed cinematic concept art. Zero-gravity floating screens displaying "
            "space-themed digital artworks. Earth curvature and the Milky Way visible through the dome. "
            "Bioluminescent ambient lighting, floating holographic color palettes and brushes. Sleek white "
            "and chrome furniture with iridescent surfaces. Nebula reflections on every glass surface. "
            "Unreal Engine 5 quality, epic scale, awe-inspiring, 8K."
        ),
        "hook": "🚀 Creating art among the stars.",
        "vibe": "epic, cosmic, awe-inspiring"
    },
    {
        "id": 4,
        "name": "Enchanted Forest Artist Cottage",
        "prompt": (
            "A magical enchanted forest artist cottage workspace, ultra-detailed fantasy digital painting. "
            "Ancient gnarled tree roots forming the desk, glowing with bioluminescent light. Crystal orb "
            "monitors displaying ethereal digital artworks. Fireflies dancing, mystical spell books floating "
            "open. Moss-covered stone walls, stained glass window casting rainbow light patterns. Tiny fairy "
            "doors, mushroom clusters, flowing water nearby. Deep emerald and violet with golden accents. "
            "Brian Froud meets concept art, magical realism, 8K."
        ),
        "hook": "🌿 Where magic and art become one.",
        "vibe": "magical, ethereal, fantasy"
    },
    {
        "id": 5,
        "name": "Minimalist Zen White Studio",
        "prompt": (
            "A breathtakingly minimalist zen digital art studio, ultra-detailed architectural photography "
            "style. Pure white floating desk, single 32-inch OLED monitor displaying vivid digital artwork "
            "as the only color in the room. Polished white concrete floors, floor-to-ceiling frosted glass "
            "walls diffusing soft daylight. Single sculptural bonsai tree, hidden LED strip lighting. "
            "Flawless marble surfaces, a single orchid in a minimalist vase. Architectural Digest quality, "
            "luxury editorial style, perfect symmetry, 8K detail."
        ),
        "hook": "🤍 Clarity creates masterpieces.",
        "vibe": "clean, luxury, zen"
    },
    {
        "id": 6,
        "name": "Retro Synthwave Arcade Studio",
        "prompt": (
            "A stunning retro 80s synthwave digital artist arcade studio, ultra-detailed neon-drenched "
            "illustration. Chrome and hot pink desk with vintage CRT monitor showing pixel art alongside "
            "a modern drawing tablet. Neon grid floors extending to the horizon. Palm tree silhouettes, "
            "purple and orange sunset through venetian blinds. VHS tapes, cassette players, neon signs "
            "reading CREATE and DREAM. Arcade cabinets repurposed as storage. "
            "Outrun aesthetic, extreme neon glow and reflection detail, lo-fi retro-futurism, 8K cinematic."
        ),
        "hook": "🎸 Riding the retrowave of creation.",
        "vibe": "neon, retro, electric"
    },
    {
        "id": 7,
        "name": "Underwater Bioluminescent Studio",
        "prompt": (
            "An impossibly beautiful underwater digital art studio inside a transparent glass bubble, "
            "ultra-detailed fantasy concept art. Bioluminescent coral and jellyfish floating past curved "
            "glass walls. Deep ocean blue and teal ambient lighting with shifting caustic light patterns. "
            "Kelp forests visible outside, a whale swimming majestically in the distance. Waterproof "
            "holographic screens, pearl and shell decorations. The monitors show ocean-inspired digital "
            "paintings. Dreamlike surrealism meets photorealism, Miyazaki meets James Cameron, 8K."
        ),
        "hook": "🌊 Deep creativity lives deeper.",
        "vibe": "surreal, blue, dreamlike"
    },
    {
        "id": 8,
        "name": "Victorian Library Meets Future Tech",
        "prompt": (
            "An extraordinary fusion of Victorian-era grand library and futuristic technology, "
            "ultra-detailed steampunk digital art workspace. Towering mahogany bookshelves, "
            "cathedral ceilings, rolling brass ladders, leather-bound ancient books. In the center, "
            "an advanced holographic workstation with floating screens showing intricate digital artworks. "
            "Warm candlelight mixing with cool blue holographic glow. Mechanical clockwork elements, "
            "brass gears and copper pipes in the desk. Vintage globes alongside neural interface headsets. "
            "Steampunk perfection, cinematic lighting, extraordinary detail, 8K render."
        ),
        "hook": "📚 Where history meets the future of art.",
        "vibe": "steampunk, rich, dramatic"
    },
    {
        "id": 9,
        "name": "Pastel Kawaii Dream Studio",
        "prompt": (
            "An ultra-cute kawaii pastel dream digital art studio, hyper-detailed Japanese illustration "
            "style with 3D render quality. Lavender, mint, peach and baby blue palette throughout. "
            "Cloud-shaped desk floating on fluffy white clouds, star and moon shaped monitors displaying "
            "adorable digital artworks. Plushies and figurines lined up neatly, tiny macarons and "
            "strawberry drinks. Sparkles and tiny stars floating in air, rainbow prisms everywhere. "
            "Flower garlands around monitors, a sleepy cat on a cloud cushion. "
            "Sanrio meets Studio Trigger meets 3D illustration, impossibly sweet, 8K."
        ),
        "hook": "🌸 Art as sweet as your imagination.",
        "vibe": "cute, pastel, joyful"
    },
    {
        "id": 10,
        "name": "Industrial Loft Artist Sanctuary",
        "prompt": (
            "A jaw-dropping industrial loft digital art sanctuary, ultra-detailed interior design "
            "photography quality. Exposed brick walls, raw concrete ceilings with original steel beams, "
            "oversized factory windows flooding the space with dramatic natural light and long shadows. "
            "Reclaimed wood desk 3 meters long, dual 4K monitors showing portfolio work, Wacom Cintiq Pro, "
            "professional color calibration tools. Original artwork canvases leaning against brick walls. "
            "Edison bulb pendant lights, vintage Persian rugs on polished concrete floors. "
            "Coffee station built into a repurposed industrial cabinet. Kinfolk magazine aesthetic, "
            "extraordinary texture detail, 8K quality."
        ),
        "hook": "🏭 Raw space. Pure creativity.",
        "vibe": "industrial, raw, sophisticated"
    },
]

# ══════════════════════════════════════════════
# ROTATING HASHTAG SETS
# ══════════════════════════════════════════════
HASHTAG_SETS = [
    "#AIArt #DigitalArt #AIGenerated #GenerativeArt #AIArtwork #DigitalArtist #FuturisticArt #WorkspaceGoals #DeskSetup #CreativeWorkspace #ArtStudio #ArtDesk #WorkspaceDesign #ArtisticVibes #CreativeSpace #StudioVibes #DeskGoals #ArtInspiration #DigitalCreative #TechArt #ArtCommunity #CreatorSpace #InstaArt #ArtDaily #AICreative #ConceptArt #artofinstagram #digitalartist #aiartist #workspaceinspo",
    "#AestheticWorkspace #DreamDesk #ProductivitySetup #NeonAesthetic #CyberpunkArt #LoFiVibes #ArtisticSetup #CreativeLife #DesignerLife #StudioAesthetic #HomestudioSetup #TechSetup #FuturisticDesign #SciFiArt #NeonLights #SynthwaveArt #RetroFuturism #ArtMotivation #CreativeMotivation #ArtVibes #VisualArt #DigitalDesign #ArtOfTheDay #DailyArt #InspirationArt #ArtGallery #ArtLovers #aiartist #digitalartwork #CreativeStudio",
    "#ExploreArt #CreativeCommunity #ArtisticExpression #AITools #AIImageGeneration #AIArtCommunity #DigitalArtwork #AbstractArt #ModernArt #TechAesthetic #FutureTech #TechVibes #InnovationArt #CreatorEconomy #ContentCreator #InstagramArt #VisualDesign #GraphicArt #desksetup #AIGenerated #ArtificialIntelligence #PixelArt #ConceptArtist #madewithai #artstation #designinspiration #creativeprocess #digitalillustration #fantasyart #scifiart",
]

POST_GAP_SECONDS = 90 * 60  # 90 min between posts
POST_TIMES = ["08:00","09:30","11:00","13:00","15:00","17:00","18:30","20:00","21:30","23:00"]


# ══════════════════════════════════════════════
# STEP 1 — GENERATE IMAGE
# ══════════════════════════════════════════════
def generate_image(theme: dict, index: int):
    print(f"\n  🎨 [{index+1}/10] {theme['name']}  |  vibe: {theme['vibe']}")

    response = client.images.generate(
        model="dall-e-3",
        prompt=theme["prompt"],
        size="1024x1024",
        quality="hd",
        style="vivid",
        n=1,
    )

    image_url      = response.data[0].url
    revised_prompt = response.data[0].revised_prompt

    img_bytes = requests.get(image_url).content
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename  = f"{SAVE_DIR}/post_{index+1:02d}_{timestamp}.png"

    img = Image.open(io.BytesIO(img_bytes))
    img.save(filename, "PNG")

    print(f"      💾 Saved: {filename}  ({img.size[0]}x{img.size[1]}px)")
    return filename, revised_prompt


# ══════════════════════════════════════════════
# STEP 2 — GENERATE CAPTION
# ══════════════════════════════════════════════
def generate_caption(theme: dict, hashtag_set: str) -> str:
    print(f"      ✍️  Writing caption...")

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": (
                    "You write punchy viral Instagram captions for an AI digital art workspace account.\n"
                    "Rules: max 4 lines, use the hook on line 1, lines 2-3 are dreamy and inspiring, "
                    "line 4 is a CTA (save this / tag a friend / drop a fire emoji). "
                    "Use 3-5 emojis naturally. No hashtags. Sound human and passionate."
                )
            },
            {
                "role": "user",
                "content": f"Theme: {theme['name']}\nHook: {theme['hook']}\nVibe: {theme['vibe']}\nWrite the caption."
            }
        ],
        max_tokens=150,
        temperature=0.85,
    )

    body = response.choices[0].message.content.strip()
    return f"{body}\n\n🤖 Made with AI ✨\n\n{hashtag_set}"


# ══════════════════════════════════════════════
# STEP 3 — IMGUR UPLOAD
# ══════════════════════════════════════════════
def imgur_upload(image_path: str) -> str:
    if not IMGUR_CLIENT_ID:
        print("      ❌ IMGUR_CLIENT_ID not set in .env")
        return None

    print(f"      📤 Uploading to Imgur...")
    with open(image_path, "rb") as f:
        r = requests.post(
            "https://api.imgur.com/3/image",
            headers={"Authorization": f"Client-ID {IMGUR_CLIENT_ID}"},
            files={"image": f}
        )
    data = r.json()
    if data.get("success"):
        url = data["data"]["link"]
        print(f"      🌐 {url}")
        return url
    print(f"      ❌ Imgur error: {data}")
    return None


# ══════════════════════════════════════════════
# STEP 4 — POST TO INSTAGRAM
# ══════════════════════════════════════════════
def post_to_instagram(image_path: str, caption: str) -> str:
    if not INSTAGRAM_ACCOUNT_ID or not ACCESS_TOKEN:
        print("      ❌ Instagram credentials missing in .env")
        return None

    public_url = imgur_upload(image_path)
    if not public_url:
        return None

    # Create container
    r1 = requests.post(
        f"https://graph.facebook.com/v19.0/{INSTAGRAM_ACCOUNT_ID}/media",
        data={"image_url": public_url, "caption": caption, "access_token": ACCESS_TOKEN}
    )
    res1 = r1.json()
    if "id" not in res1:
        print(f"      ❌ Container error: {res1}")
        return None

    container_id = res1["id"]
    print(f"      📦 Container: {container_id} — processing (8s)...")
    time.sleep(8)

    # Publish
    r2 = requests.post(
        f"https://graph.facebook.com/v19.0/{INSTAGRAM_ACCOUNT_ID}/media_publish",
        data={"creation_id": container_id, "access_token": ACCESS_TOKEN}
    )
    res2 = r2.json()
    if "id" in res2:
        print(f"      ✅ POSTED! Media ID: {res2['id']}")
        return res2["id"]
    print(f"      ❌ Publish error: {res2}")
    return None


# ══════════════════════════════════════════════
# LOGGING
# ══════════════════════════════════════════════
def log_post(theme, image_path, caption, media_id, revised_prompt=""):
    log = json.load(open(LOG_FILE)) if os.path.exists(LOG_FILE) else []
    log.append({
        "timestamp":      datetime.now().isoformat(),
        "theme":          theme["name"],
        "image_path":     image_path,
        "caption":        caption[:120] + "...",
        "revised_prompt": revised_prompt[:200],
        "media_id":       str(media_id) if media_id else "failed",
        "status":         "posted" if media_id else "failed"
    })
    with open(LOG_FILE, "w") as f:
        json.dump(log, f, indent=2)


# ══════════════════════════════════════════════
# SUMMARY REPORT
# ══════════════════════════════════════════════
def print_summary(results):
    ok = sum(1 for r in results if r["ok"])
    print(f"\n{'═'*50}")
    print(f"  📊 SUMMARY — {datetime.now().strftime('%Y-%m-%d')}")
    print(f"  ✅ Posted: {ok}/10  |  ❌ Failed: {10-ok}/10")
    print(f"{'─'*50}")
    for r in results:
        icon = "✅" if r["ok"] else "❌"
        print(f"  {icon}  {r['name']}")
    print(f"{'═'*50}\n")


# ══════════════════════════════════════════════
# MAIN DAILY JOB
# ══════════════════════════════════════════════
def run_daily_posts():
    print(f"\n{'═'*50}")
    print(f"  🚀 BOT STARTING — {datetime.now().strftime('%A %d %B %Y %H:%M')}")
    print(f"{'═'*50}")

    day_of_year = datetime.now().timetuple().tm_yday
    hashtag_set = HASHTAG_SETS[day_of_year % len(HASHTAG_SETS)]

    themes_today = THEMES.copy()
    random.shuffle(themes_today)

    results = []

    for i, theme in enumerate(themes_today):
        print(f"\n{'─'*50}")
        print(f"  📸 POST {i+1}/10  |  ⏰ {POST_TIMES[i]}")
        print(f"{'─'*50}")
        try:
            image_path, revised_prompt = generate_image(theme, i)
            caption  = generate_caption(theme, hashtag_set)
            media_id = post_to_instagram(image_path, caption)
            log_post(theme, image_path, caption, media_id, revised_prompt)
            results.append({"name": theme["name"], "ok": bool(media_id)})

            if i < 9:
                print(f"\n  ⏳ Waiting {POST_GAP_SECONDS//60} min before next post...")
                time.sleep(POST_GAP_SECONDS)

        except Exception as e:
            print(f"  ❌ Error: {e}")
            log_post(theme, "", "", None)
            results.append({"name": theme["name"], "ok": False})

    print_summary(results)


# ══════════════════════════════════════════════
# TEST MODE
# ══════════════════════════════════════════════
def test_mode():
    print("\n🧪 TEST MODE — 1 image, no Instagram posting\n")
    theme = THEMES[0]
    image_path, revised_prompt = generate_image(theme, 0)
    caption = generate_caption(theme, HASHTAG_SETS[0])

    print(f"\n{'─'*50}")
    print("📝 CAPTION PREVIEW:")
    print(f"{'─'*50}")
    print(caption)
    print(f"{'─'*50}")
    print(f"\n✅ Test complete!  Image saved: {image_path}")


# ══════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════
if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "schedule"

    if mode == "test":
        test_mode()

    elif mode == "now":
        run_daily_posts()

    elif mode == "single":
        # python bot.py single 3  →  post only theme #3
        idx   = int(sys.argv[2]) - 1 if len(sys.argv) > 2 else 0
        theme = THEMES[idx]
        print(f"\n📸 Posting single theme: {theme['name']}\n")
        image_path, revised_prompt = generate_image(theme, idx)
        caption  = generate_caption(theme, HASHTAG_SETS[0])
        media_id = post_to_instagram(image_path, caption)
        log_post(theme, image_path, caption, media_id, revised_prompt)

    else:
        print("╔══════════════════════════════════════════╗")
        print("║   Instagram AI Bot — Scheduler Mode      ║")
        print("╠══════════════════════════════════════════╣")
        print("║  Runs every day at 08:00 AM              ║")
        print("║                                          ║")
        print("║  python bot.py test      → test 1 image  ║")
        print("║  python bot.py now       → post all 10   ║")
        print("║  python bot.py single 3  → post theme 3  ║")
        print("╚══════════════════════════════════════════╝\n")
        schedule.every().day.at("08:00").do(run_daily_posts)
        while True:
            schedule.run_pending()
            time.sleep(60)
